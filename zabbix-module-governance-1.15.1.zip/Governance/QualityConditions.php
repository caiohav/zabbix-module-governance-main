<?php
namespace Modules\Governance;

use InvalidArgumentException;

/** Shared selection rules for saved indicators and unsaved previews. No expressions/eval. */
final class QualityConditions {
    const INVENTORY = ['os', 'os_full', 'os_short', 'serialno_a', 'serialno_b', 'location', 'type', 'software', 'hardware', 'name', 'contact'];

    public static function validate($selection): array {
        if (!is_array($selection) || ($selection['version'] ?? null) !== 1
                || !in_array($selection['mode'] ?? null, ['all', 'any'], true)
                || !is_array($selection['conditions'] ?? null)
                || array_values($selection['conditions']) !== $selection['conditions'] || count($selection['conditions']) > 20) {
            throw new InvalidArgumentException('Invalid host selection / Seleção de hosts inválida (máximo 20 condições).');
        }
        $conditions = [];
        foreach ($selection['conditions'] as $condition) {
            if (!is_array($condition)) { throw new InvalidArgumentException('Invalid condition / Condição inválida.'); }
            $type = $condition['type'] ?? '';
            $ops = ['tag' => ['equals', 'not_equals', 'exists', 'not_exists'], 'group' => ['equals', 'not_equals'],
                'template' => ['equals', 'not_equals'], 'inventory' => ['exists', 'not_exists']];
            if (!is_string($type) || !isset($ops[$type]) || !in_array($condition['operator'] ?? null, $ops[$type], true)) {
                throw new InvalidArgumentException('Invalid condition operator / Operador de condição inválido.');
            }
            $row = ['type' => $type, 'operator' => $condition['operator']];
            foreach (['name', 'value'] as $key) {
                $text = $condition[$key] ?? '';
                if (!is_string($text) || mb_strlen($text) > 255 || preg_match('/[\x00-\x1f\x7f]/', $text)) {
                    throw new InvalidArgumentException('Invalid condition text / Texto da condição inválido.');
                }
                $row[$key] = trim($text);
            }
            $children = $condition['subgroups'] ?? 1;
            if (!in_array($children, [0, 1, '0', '1', true, false], true)) { throw new InvalidArgumentException('Invalid subgroups / Subgrupos inválidos.'); }
            $row['subgroups'] = (int) (bool) $children;
            if (($type === 'tag' && $row['name'] === '')
                    || (in_array($type, ['group', 'template'], true) && !self::items($row['value']))
                    || ($type === 'inventory' && !in_array($row['name'], self::INVENTORY, true))) {
                throw new InvalidArgumentException('Complete the condition fields / Preencha os campos da condição.');
            }
            $conditions[] = $row;
        }
        return ['version' => 1, 'mode' => $selection['mode'], 'conditions' => $conditions];
    }

    public static function fromCard(array $card): array {
        if (isset($card['selection'])) { return self::validate($card['selection']); }
        $rows = [];
        if (($card['scope_tag_name'] ?? '') !== '') {
            $rows[] = ['type' => 'tag', 'operator' => ($card['scope_tag_value'] ?? '') === '' ? 'exists' : 'equals',
                'name' => $card['scope_tag_name'], 'value' => $card['scope_tag_value'] ?? '', 'subgroups' => 1];
        }
        if (($card['scope_group_names'] ?? '') !== '') {
            $rows[] = ['type' => 'group', 'operator' => 'equals', 'name' => '', 'value' => $card['scope_group_names'],
                'subgroups' => $card['scope_include_subgroups'] ?? 1];
        }
        return self::validate(['version' => 1, 'mode' => 'all', 'conditions' => $rows]);
    }

    private static function lower(string $value): string { return mb_strtolower(trim($value), 'UTF-8'); }
    private static function items(string $value): array { return array_values(array_filter(array_unique(array_map([self::class, 'lower'], explode(',', $value))), static function($v) { return $v !== ''; })); }

    public static function matches(array $host, array $selection): bool {
        if (!$selection['conditions']) { return true; }
        foreach ($selection['conditions'] as $row) {
            $match = self::condition($host, $row);
            if ($selection['mode'] === 'all' && !$match) { return false; }
            if ($selection['mode'] === 'any' && $match) { return true; }
        }
        return $selection['mode'] === 'all';
    }

    private static function condition(array $host, array $row): bool {
        $found = false;
        switch ($row['type']) {
            case 'tag':
                foreach ($host['tags'] ?? [] as $tag) {
                    if (self::lower($tag['tag']) === self::lower($row['name'])
                            && (in_array($row['operator'], ['exists', 'not_exists'], true)
                                || self::lower($tag['value']) === self::lower($row['value']))) { $found = true; break; }
                }
                break;
            case 'group':
                foreach ($host['groups'] ?? [] as $group) {
                    foreach (self::items($row['value']) as $accepted) {
                        $prefix = rtrim($accepted, '/'); $name = self::lower($group['name']);
                        if ((string) $group['groupid'] === $accepted || $name === $prefix
                                || ($row['subgroups'] && $prefix !== '' && strpos($name, $prefix . '/') === 0)) { $found = true; break 2; }
                    }
                }
                break;
            case 'template':
                foreach ($host['parentTemplates'] ?? [] as $template) {
                    foreach (['templateid', 'host', 'name'] as $key) {
                        if (in_array(self::lower((string) ($template[$key] ?? '')), self::items($row['value']), true)) { $found = true; break 2; }
                    }
                }
                break;
            case 'inventory': $found = trim($host['inventory'][$row['name']] ?? '') !== ''; break;
        }
        return in_array($row['operator'], ['not_equals', 'not_exists'], true) ? !$found : $found;
    }

    public static function addSelects(array $options, array $cards): array {
        foreach ($cards as $card) {
            foreach ($card['selection']['conditions'] as $row) {
                switch ($row['type']) {
                    case 'tag': $options['selectTags'] = ['tag', 'value']; break;
                    case 'group': $options['selectGroups'] = ['groupid', 'name']; break;
                    case 'template': $options['selectParentTemplates'] = ['templateid', 'host', 'name']; break;
                    case 'inventory': $options['selectInventory'] = array_values(array_unique(array_merge($options['selectInventory'] ?? [], [$row['name']]))); break;
                }
            }
        }
        return $options;
    }
}
